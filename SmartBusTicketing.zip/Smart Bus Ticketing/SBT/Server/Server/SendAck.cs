﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using Server.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace Server
{
    public class SendAck : ISendAck
    {
        private ConnectionFactory connectionFactory;
        private IConnection connection;
        private IModel model;
        private string TopicName = "topic.exchange";
        IBasicProperties basicProperties;
        Dictionary<string, object> headers;
        public SendAck()
        {
           
        }

        public void SendAcknowledgement(string jsonMessage, string queueName, string headerMessage)
        {
            createQueue(queueName);
            basicProperties = model.CreateBasicProperties();
            headers = new Dictionary<string, object>();
            byte[] message = System.Text.Encoding.UTF8.GetBytes(jsonMessage);
            model.QueueBind(queueName,TopicName,$"{queueName}.route", null);
            //add header
            headers["RequestType"] = headerMessage;
            basicProperties.Headers = headers;
            model.BasicPublish(TopicName, $"{queueName}.route", basicProperties , message);
            //Console.WriteLine($"Acknowledgement has been succesfully sent to passenger :{data.passenger.PassengerName}");
            Console.WriteLine($"the delivered Ack of passenger is:{jsonMessage}");
        }

        private void createQueue(string queueName)
        {
            connectionFactory = new ConnectionFactory
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "guest"
            };
            connection = connectionFactory.CreateConnection();
            model = connection.CreateModel();
            model.QueueDeclare(queueName, true, false, false, null);
            model.BasicQos(0, 1, false);
        }
    }
}
