﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers.RouteMap
{
    public static class EndLocations
    {
        public static Dictionary<string, string> endDestinations = new Dictionary<string, string>
        {
            {"1d918ed3-af81-45d7-a050-38d7c0844554","Banashankari" },
            {"b527ca75-967e-43d5-ad85-f48937fb3e9a","Bellandur" }
        };
    }
}
