﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers.RouteMap
{
    public class RouteModel
    {
        public Dictionary<string,int> route { get; set; }
    }
}
