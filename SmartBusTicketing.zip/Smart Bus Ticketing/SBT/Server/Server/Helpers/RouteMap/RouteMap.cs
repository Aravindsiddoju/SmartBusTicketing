﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers.RouteMap
{
    public static class RouteMap
    {
        public static Dictionary<string, RouteModel> routeMap = new Dictionary<string, RouteModel> {
            {
                "1d918ed3-af81-45d7-a050-38d7c0844554",
                new RouteModel{
                    route = new Dictionary<string, int>
                    {
                        { "Marathalli", 0},
                        { "Bellandur", 10 },
                        { "Agara", 15 },
                        { "HSR", 20 },
                        { "Silk Board", 25 },
                        { "BTM Layout", 30 },
                        { "Jayanagar", 35 },
                        { "JP Nagar", 40 },
                        { "Banashankari", 45 }
                    }
                }
            },
            {
                "b527ca75-967e-43d5-ad85-f48937fb3e9a",
                new RouteModel
                {
                    route = new Dictionary<string, int>
                    {
                        {"marathalli",0},
                        {"bellandur",10 },
                        {"silkboard",20 }
                    }
                }
            }
        };
    }
}