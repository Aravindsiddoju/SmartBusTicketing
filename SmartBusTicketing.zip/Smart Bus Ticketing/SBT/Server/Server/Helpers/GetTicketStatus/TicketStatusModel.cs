﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers.GetTicketStatus
{
    public class TicketStatusModel
    {
        public string ticketId { get; set; }
        public string fromLocation { get; set; }
        public string toLocation { get; set; }
        public string passengerCount { get; set; }

        //0-Ongoing, 1-Completed
        public int ticketStatus { get; set; }
        public string amountDeducted { get; set; }
    }
}
