﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class DataFromBus
    {
        public DataFromBus()
        {

        }
        public Bus bus;
        public Passenger passenger;
    }
}
