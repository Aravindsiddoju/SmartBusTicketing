﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class Bus
    {
        private string serviceNumber;
        private string busId;

        public string BusId
        {
            get { return busId; }
            set { busId = value; }
        }
        public string ServiceNumber
        {
            get { return serviceNumber; }
            set { serviceNumber = value; }
        }

    }
}
