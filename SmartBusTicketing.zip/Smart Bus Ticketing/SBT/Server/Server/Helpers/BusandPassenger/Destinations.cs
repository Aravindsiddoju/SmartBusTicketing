﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class Destinations
    {
        public string location;
        public int relativePrice;
    }
}
