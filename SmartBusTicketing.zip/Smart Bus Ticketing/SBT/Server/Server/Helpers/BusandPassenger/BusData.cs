﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public static class BusData
    {
        public static Dictionary<string, BusInfo> businfo = new Dictionary<string, BusInfo>
        {
            {"1d918ed3-af81-45d7-a050-38d7c0844554",new BusInfo{
                busId ="1d918ed3-af81-45d7-a050-38d7c0844554",
                serviceNumber = "321",

                destinations = new Dictionary<int,Destinations>
                {
                    {1,new Destinations{
                    location = "Marathalli",
                    relativePrice = 0}
                    },
                {2,new Destinations{
                    location = "Bellandur",
                    relativePrice = 10
                    }
                },
                {3,new Destinations{
                    location = "Agara",
                    relativePrice = 15
                    }
                },
                    {
                        4,new Destinations
                        {
                            location = "HSR",
                            relativePrice = 20
                        }
                    },
                    {
                        5, new Destinations
                        {
                            location = "Silk Board",
                            relativePrice = 25
                        }
                    },
                    {6,new Destinations{
                    location = "BTM Layout",
                    relativePrice = 30
                    }
                },
                    {
                        7,new Destinations
                        {
                            location = "Jayanagar",
                            relativePrice = 35
                        }
                    },
                    {8,new Destinations{
                    location = "JP Nagar",
                    relativePrice = 40
                    }
                },
                    {
                        9,new Destinations
                        {
                            location = "Banashankari",
                            relativePrice = 45
                        }
                    }
                
               },
               
            fromLocation = "Marathalli"
                
               }
            },
            {"b527ca75-967e-43d5-ad85-f48937fb3e9a",new BusInfo{
                busId ="b527ca75-967e-43d5-ad85-f48937fb3e9a",
                serviceNumber = "321",

                destinations = new Dictionary<int,Destinations>
                {
                    {1,new Destinations{
                    location = "Marathalli",
                    relativePrice = 0}
                    },
                {2,new Destinations{
                    location = "Bellandur",
                    relativePrice = 10
                                    }
                }

               },

            fromLocation = "Marathalli"

               }
            }



        };

    }
}