﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class LiveLocation
    {
        public string busId;
        public string location;
    }

    public class IotDeviceInfo
    {
        public string busId;
    }
}
