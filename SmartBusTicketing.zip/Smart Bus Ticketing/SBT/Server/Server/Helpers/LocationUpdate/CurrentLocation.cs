﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public static class CurrentLocation
    {
        public static Dictionary<string, string> currentLocationStored = new Dictionary<string, string>
        {
            { "1d918ed3-af81-45d7-a050-38d7c0844554","marathalli"},
            {"b527ca75-967e-43d5-ad85-f48937fb3e9a ","marathalli" }
        };
    }
}
