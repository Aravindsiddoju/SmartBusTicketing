﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class BusInfo
    {
        public string busId;
        public string serviceNumber;
        public Dictionary<int,Destinations> destinations;
        public string fromLocation;
    }
}
