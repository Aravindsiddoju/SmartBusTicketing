﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class InputForBusInfo
    {
        public string busId;
        public string passengerId;
    }
}
