﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class Acknowledgement
    {
        public string PassengerId;
        public string TicketId;
        public string TimeStamp;
        public string numberOfTickets;
        public string amountHold;
    }
}
