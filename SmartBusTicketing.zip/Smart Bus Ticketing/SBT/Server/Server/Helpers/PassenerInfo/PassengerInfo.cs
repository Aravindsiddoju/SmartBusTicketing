﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers.PassenerInfo
{
    public static class PassengerInfo
    {
        public static Dictionary<string, PassengerData> passengerInfo = new Dictionary<string, PassengerData>
        {
            { "001",new PassengerData
            {
                walletBalance = 500,
                ticketInfo = null
            }
        }
        };
    }

    public class PassengerData
    {
        public int walletBalance;
        public TicketInfo ticketInfo;

    }
}
