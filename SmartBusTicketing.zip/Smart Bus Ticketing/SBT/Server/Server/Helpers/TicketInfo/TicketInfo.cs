﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class TicketInfo
    {
        public string busId;
        public string ticketId;
        public string fromLocation;
        public string  timeStamp;
        public string amountHold;
        public string numberOfTickets;
    }
}
