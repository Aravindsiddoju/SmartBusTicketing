﻿using Server.Helpers.GetTicketStatus;
using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class StoredTickedIds
    {
        public static Dictionary<string, TicketInfo> storedTicketIds= new Dictionary<string, TicketInfo> {
            };
    }


    public static class ArchiveTicketIds
    {
        public static Dictionary<string, List<TicketStatusModel>> ArchiveTickets = new Dictionary<string, List<TicketStatusModel>> { };
    }
}
