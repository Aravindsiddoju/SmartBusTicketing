﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers.Endtrip
{
    class EndTripOutput
    {
        public string ticketId;
        public int deductedAmount;
        public string endTripStatus;
        public string fromLocation;
        public string endLocation;
    }
}
