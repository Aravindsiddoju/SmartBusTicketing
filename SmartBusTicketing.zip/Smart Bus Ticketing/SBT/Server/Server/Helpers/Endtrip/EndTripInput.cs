﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers.Endtrip
{
    public class EndTripInput
    {
        public string passengerId;
        public string ticketId;
        
       // public string endTime;
    }
}
