﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Helpers
{
    public class UpdatedTicketInput
    {
        public string passengerId;
        public string ticketId;
    }
}
