﻿using Microsoft.Extensions.Hosting;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Server
{
    class Application : IHostedService
    {

        private ConnectionFactory connectionFactory;
        private IConnection connection;
        private IModel model;
        private string QueueName1 = "BusInfo";
        private string QueueName2 = "PassengerInfo";
        private string QueueName3 = "BookTicket";
        private string QueueName4 = "EndTrip";
        private string QueueName5 = "LiveLocation";
        private string QueueName6 = "GetRoute";
        private string QueueName7 = "TicketStatus";

        private IServerBusiness serverBusiness;
        public Application(IServerBusiness _serverBusiness)
        {
            CreateQueue();
            serverBusiness = _serverBusiness;
        }
       
        public Task StartAsync(CancellationToken cancellationToken)
        {           
            var consumer1 = new EventingBasicConsumer(model);
            var consumer2 = new EventingBasicConsumer(model);
            var consumer3 = new EventingBasicConsumer(model);
            var consumer4 = new EventingBasicConsumer(model);
            var consumer5 = new EventingBasicConsumer(model);
            var consumer6 = new EventingBasicConsumer(model);
            var consumer7 = new EventingBasicConsumer(model);            
            
            Console.WriteLine("server started listening for new messages");
            consumer1.Received += Consumer_Received1;
            consumer2.Received += Consumer_Received2;
            consumer3.Received += Consumer_Received3;
            consumer4.Received += Consumer_Received4;
            consumer5.Received += Consumer_Received5;
            consumer6.Received += Consumer_Received6;
            consumer7.Received += Consumer_Received7;
            model.BasicConsume(QueueName1, false, consumer1);
            model.BasicConsume(QueueName2, false, consumer2);
            model.BasicConsume(QueueName3, false, consumer3);
            model.BasicConsume(QueueName4, false, consumer4);
            model.BasicConsume(QueueName5, false, consumer5);
            model.BasicConsume(QueueName6, false, consumer6);
            model.BasicConsume(QueueName7, false, consumer7);            
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        /// <summary>
        /// this method listens the responses from queue one by one.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        internal void Consumer_Received1(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                
                Console.WriteLine("received a new message from passenger");
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine("started processing the message");
                var header = e.BasicProperties.Headers;
                if (header.ContainsKey("RequestType"))
                {   
                    var x = ASCIIEncoding.ASCII.GetString(header["RequestType"] as byte[]);
                    switch (x)
                    {
                        case "BusInfo":
                            {
                                serverBusiness.ProcessMessageForBusInfo(messageBody);
                                break;
                            }
                        
                    }
                }
                //serverBusiness.ProcessMessages(messageBody);
        
                model.BasicAck(e.DeliveryTag,false);
                

            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }

   
        internal void Consumer_Received2(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                Console.WriteLine("received a new message from Iot device");
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine("started processing the message");
                var header = e.BasicProperties.Headers;
                if (header.ContainsKey("RequestType"))
                {
                    var x = ASCIIEncoding.ASCII.GetString(header["RequestType"] as byte[]);
                    switch (x)
                    {

                        case "PassengerInfo":
                            {
                                serverBusiness.ProcesMessageForPassengerInfo(messageBody);
                                break;
                            }

                    }
                }
                model.BasicAck(e.DeliveryTag, false);

            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }
        internal void Consumer_Received3(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                Console.WriteLine("received a new message from Iot device");
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine("started processing the message");
                var header = e.BasicProperties.Headers;
                if (header.ContainsKey("RequestType"))
                {
                    var x = ASCIIEncoding.ASCII.GetString(header["RequestType"] as byte[]);
                    switch (x)
                    {

                        case "BookTicket":
                            {
                                serverBusiness.ProcesMessageForBooking(messageBody);
                                break;
                            }

                    }
                }
                model.BasicAck(e.DeliveryTag, false);

            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }
        internal void Consumer_Received4(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                Console.WriteLine("received a new message from Iot device");
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine("started processing the message");
                var header = e.BasicProperties.Headers;
                if (header.ContainsKey("RequestType"))
                {
                    var x = ASCIIEncoding.ASCII.GetString(header["RequestType"] as byte[]);
                    switch (x)
                    {

                        case "EndTrip":
                            {
                                serverBusiness.ProcessMessageForEndTrip(messageBody);
                                break;
                            }

                    }
                }
                model.BasicAck(e.DeliveryTag, false);
                stopwatch.Stop();
                Console.WriteLine($"the elapsed time for Endtrip is {stopwatch.ElapsedMilliseconds}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }
        internal void Consumer_Received5(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                Console.WriteLine("received a new message from Iot device");
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine("started processing the message");
                var header = e.BasicProperties.Headers;
                if (header.ContainsKey("RequestType"))
                {
                    var x = ASCIIEncoding.ASCII.GetString(header["RequestType"] as byte[]);
                    switch (x)
                    {

                        case "LiveLocation":
                            {
                                serverBusiness.ProcessMessageForLiveLocation(messageBody);
                                break;

                            }

                    }
                }
                model.BasicAck(e.DeliveryTag, false);

            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }
        internal void Consumer_Received6(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                Console.WriteLine("received a new message from Iot device");
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine("started processing the message");
                var header = e.BasicProperties.Headers;
                if (header.ContainsKey("RequestType"))
                {
                    var x = ASCIIEncoding.ASCII.GetString(header["RequestType"] as byte[]);
                    switch (x)
                    {

                        case "GetRoute":
                            {
                                serverBusiness.ProcessMessageForGetRoute(messageBody);
                                break;

                            }

                    }
                }
                model.BasicAck(e.DeliveryTag, false);

            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }

        internal void Consumer_Received7(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                Console.WriteLine("received a new message from Iot device");
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine("started processing the message");
                var header = e.BasicProperties.Headers;
                if (header.ContainsKey("RequestType"))
                {
                    var x = ASCIIEncoding.ASCII.GetString(header["RequestType"] as byte[]);
                    switch (x)
                    {

                        case "TicketStatus":
                            {
                                serverBusiness.ProcessMessageForUpdatedTicketDetails(messageBody);
                                break;

                            }

                    }
                }
                model.BasicAck(e.DeliveryTag, false);

            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }

        /// <summary>
        /// this method will create the queue if it does not exist, else it will connect to the existing queue.
        /// </summary>
        private void CreateQueue()
        {
            connectionFactory = new ConnectionFactory
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "guest",
                Port = 5672,
                VirtualHost = "/"
            };
            connection = connectionFactory.CreateConnection();
            model = connection.CreateModel();
            model.QueueDeclare(QueueName1, true, false, false, null);
            model.QueueDeclare(QueueName2, true, false, false, null);
            model.QueueDeclare(QueueName3, true, false, false, null);
            model.QueueDeclare(QueueName4, true, false, false, null);
            model.QueueDeclare(QueueName5, true, false, false, null);
            model.QueueDeclare(QueueName6, true, false, false, null);
            model.QueueDeclare(QueueName7, true, false, false, null);
            model.BasicQos(0, 1, false);

        }
    }
}
