﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;

namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            var host = new HostBuilder()
                //configure services
                .ConfigureServices((context, services) =>
                {
                    services.AddSingleton<IHostedService,Application>();
                    services.AddSingleton<IServerBusiness, ServerBusiness>();
                    services.AddSingleton<ISendAck, SendAck>();
                });
            host.RunConsoleAsync();
        }
    }
}
