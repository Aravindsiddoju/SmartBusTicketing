﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using Server.Helpers;
using Server.Helpers.Endtrip;
using Server.Helpers.GetTicketStatus;
using Server.Helpers.PassenerInfo;
using Server.Helpers.RouteMap;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Server
{
    class ServerBusiness : IServerBusiness
    {
        private ISendAck sendAck;
        System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();
        public ServerBusiness(ISendAck _sendAck)
        {
            sendAck = _sendAck;
        }
        /// <summary>
        /// this will book the ticket for the passenger.
        /// it updates the active tickets dictionary
        /// it also updates the passnger info
        /// </summary>
        /// <param name="message"></param>
        public void ProcesMessageForBooking(string message)
        {
            //write business logic here.
            DataFromBus data = JsonConvert.DeserializeObject<DataFromBus>(message);
            //string retrievedData = JsonConvert.SerializeObject(data);
            Console.WriteLine("message got processed");
            Console.WriteLine("the processsed message is");
           // Console.WriteLine(retrievedData);
            Console.WriteLine("sending Booking acknowledgement to passenger");
            //store ticket before processing.
            TicketInfo ticketInfo = new TicketInfo();
            if (StoredTickedIds.storedTicketIds.ContainsKey(data.passenger.PassengerId))
            {
                ticketInfo = StoredTickedIds.storedTicketIds[data.passenger.PassengerId];
            }
            else
            {
                ticketInfo.busId = data.bus.BusId;
                ticketInfo.fromLocation = data.passenger.FromLocation;
                ticketInfo.ticketId = Guid.NewGuid().ToString();
                ticketInfo.timeStamp = DateTime.Now.ToString();
                ticketInfo.numberOfTickets = (data.passenger.NumberOfTickets).ToString();
                string endLocationOfBus = EndLocations.endDestinations[data.bus.BusId];
                ticketInfo.amountHold = Math.Abs(data.passenger.NumberOfTickets*(RouteMap.routeMap[data.bus.BusId].route[endLocationOfBus] - RouteMap.routeMap[data.bus.BusId].route[data.passenger.FromLocation])).ToString();
                StoredTickedIds.storedTicketIds.Add(data.passenger.PassengerId, ticketInfo);
                //update passenger info befor send the response
                PassengerInfo.passengerInfo[data.passenger.PassengerId].ticketInfo = ticketInfo;
            }
            Acknowledgement acknowledgement = new Acknowledgement
            {
                PassengerId = data.passenger.PassengerId,
                TicketId = ticketInfo.ticketId,
                TimeStamp = ticketInfo.timeStamp,
                amountHold = (ticketInfo.amountHold).ToString(),
                numberOfTickets = (ticketInfo.numberOfTickets).ToString()
               
            };

            string jsonMessage = JsonConvert.SerializeObject(acknowledgement);
            sendAck.SendAcknowledgement(jsonMessage,data.passenger.PassengerId, "BookTicket");
        }

        /// <summary>
        /// this will give the required bus information to start ticket booking after scanning the QR code.
        /// </summary>
        /// <param name="message"></param>
        public void ProcessMessageForBusInfo(string message)
        {
            InputForBusInfo inputForBusInfo = JsonConvert.DeserializeObject<InputForBusInfo>(message);
            string busId = inputForBusInfo.busId;
            BusInfo busInfo = BusData.businfo[busId];
            busInfo.fromLocation = CurrentLocation.currentLocationStored[busId];
            string jsonMessage = JsonConvert.SerializeObject(busInfo);
            Console.WriteLine("message got processed");
            Console.WriteLine("sending BusInfo acknowledgement to passenger");
            sendAck.SendAcknowledgement(jsonMessage,inputForBusInfo.passengerId, "BusInfo");


        }

        /// <summary>
        /// this will continuously track the updated location for the Bus.
        /// </summary>
        /// <param name="message"></param>
        public void ProcessMessageForLiveLocation(string message)
        {
            LiveLocation liveLocation = JsonConvert.DeserializeObject<LiveLocation>(message);
            CurrentLocation.currentLocationStored[liveLocation.busId] = liveLocation.location;
            Console.WriteLine($"received updated live location for busId : {liveLocation.busId}");
            Console.WriteLine($"updated live location is {liveLocation.location}");

        }
        /// <summary>
        /// this will succesfully completes passengers journey
        /// it will also delete any active ticket for the passenger
        /// </summary>
        /// <param name="message"></param>
        public void ProcessMessageForEndTrip(string message)
        {
            EndTripInput endTripInput = JsonConvert.DeserializeObject<EndTripInput>(message);
            string passengerId = endTripInput.passengerId;
            string busId = StoredTickedIds.storedTicketIds[passengerId].busId;
            string startLocation = StoredTickedIds.storedTicketIds[passengerId].fromLocation;
            string endLocation = CurrentLocation.currentLocationStored[busId];
            int walletBalance = PassengerInfo.passengerInfo[passengerId].walletBalance;
            int deductedMoney = Math.Abs(RouteMap.routeMap[busId].route[endLocation]-RouteMap.routeMap[busId].route[startLocation])*(Convert.ToInt32(StoredTickedIds.storedTicketIds[passengerId].numberOfTickets));
            PassengerInfo.passengerInfo[passengerId].walletBalance = walletBalance-deductedMoney;
      
            EndTripOutput endTripOutput = new EndTripOutput {
                 deductedAmount = deductedMoney,
                 endTripStatus = "success",
                 ticketId = endTripInput.ticketId,
                 fromLocation = startLocation,
                 endLocation = endLocation};
            Console.WriteLine("message got processed for endtrip");
            Console.WriteLine($"sending endtrip status to passenger {passengerId}");
            TicketStatusModel ticketStatusModel = new TicketStatusModel
            {
                ticketId = endTripInput.ticketId,
                fromLocation = startLocation,
                toLocation = endLocation,
                passengerCount = StoredTickedIds.storedTicketIds[passengerId].numberOfTickets,
                ticketStatus = 1,
                amountDeducted = deductedMoney.ToString()
            };
            if(ArchiveTicketIds.ArchiveTickets.ContainsKey(passengerId))
            {
                ArchiveTicketIds.ArchiveTickets[passengerId].Add(ticketStatusModel);
            }
            else
            {
                ArchiveTicketIds.ArchiveTickets.Add(passengerId, new List<TicketStatusModel> { ticketStatusModel });
            }
            StoredTickedIds.storedTicketIds.Remove(passengerId);
            //updated passenger Info dictionary
            PassengerInfo.passengerInfo[passengerId].ticketInfo = null;
            string jsonMessage = JsonConvert.SerializeObject(endTripOutput);
            sendAck.SendAcknowledgement(jsonMessage, busId, "EndTrip");
        }

        public void ProcessMessageForUpdatedTicketDetails(string message)
        {
            UpdatedTicketInput updatedTicketInput = JsonConvert.DeserializeObject<UpdatedTicketInput>(message);
            TicketStatusModel ticketStatusModel = null;
            if (StoredTickedIds.storedTicketIds.ContainsKey(updatedTicketInput.passengerId))
            {
                if (StoredTickedIds.storedTicketIds[updatedTicketInput.passengerId].ticketId == updatedTicketInput.ticketId)
                {
                    TicketInfo ticketInfo = StoredTickedIds.storedTicketIds[updatedTicketInput.passengerId];
                    ticketStatusModel = new TicketStatusModel
                    {
                        ticketId = ticketInfo.ticketId,
                        fromLocation = ticketInfo.fromLocation,
                        toLocation = "",
                        passengerCount = ticketInfo.numberOfTickets,
                        ticketStatus = 0,
                        amountDeducted = "0"
                    };
                }
            }
            else
            {
                if (ArchiveTicketIds.ArchiveTickets.ContainsKey(updatedTicketInput.passengerId))
                {
                    ticketStatusModel = ArchiveTicketIds.ArchiveTickets[updatedTicketInput.passengerId].Where(x => x.ticketId == updatedTicketInput.ticketId).FirstOrDefault();
                }

            }
                       

            string jsonMessage = JsonConvert.SerializeObject(ticketStatusModel);
            sendAck.SendAcknowledgement(jsonMessage, updatedTicketInput.passengerId, "TicketStatus");

        }

        /// <summary>
        /// this will send the route map to the requested bus
        /// </summary>
        /// <param name="message"></param>
        public void ProcessMessageForGetRoute(string message)
        {
            // IotDeviceInfo iotDeviceInfo = JsonConvert.DeserializeObject<IotDeviceInfo>(message);
            string busId = message;
           // Dictionary<int, Destinations> routeMap = BusData.businfo[busId].destinations;
            RouteInfo routeInfo = new RouteInfo();
            routeInfo.routes = BusData.businfo[busId].destinations;
            string jsonMessage = JsonConvert.SerializeObject(routeInfo);
            Console.WriteLine("message got processed for GetRoute");
            Console.WriteLine($"sending RoteMap to bus {busId}");
            sendAck.SendAcknowledgement(jsonMessage, busId, "GetRoute");
        }

        /// <summary>
        /// this will send the wallet balance and active ticket info for the requested passenger
        /// </summary>
        /// <param name="message"></param>
        public void ProcesMessageForPassengerInfo(string message)
        {
            string passengerId = message;
            PassengerData passengerData;
            if (PassengerInfo.passengerInfo.ContainsKey(passengerId))
            {
               passengerData = PassengerInfo.passengerInfo[passengerId];
            }
            else
            {
                passengerData = null;
            }
            Console.WriteLine("message got processed for GetPassengerInfo");
            Console.WriteLine($"sending PassengerInfo to passenger {passengerId}");
            string jsonMessage = JsonConvert.SerializeObject(passengerData);
            sendAck.SendAcknowledgement(jsonMessage, passengerId, "PassengerInfo");
        }

    }
}
