﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Server
{
    public interface  IServerBusiness
    {
        void ProcesMessageForBooking(string message);

        void ProcessMessageForBusInfo(string message);

        void ProcessMessageForLiveLocation(string message);

        void ProcessMessageForEndTrip(string message);

        void ProcessMessageForGetRoute(string message);

        void ProcesMessageForPassengerInfo(string message);

        void ProcessMessageForUpdatedTicketDetails(string message);

    }
}
