﻿using Server.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace Server
{
    public interface ISendAck
    {
        void SendAcknowledgement(string jsonMessage, string queueName, string headerMessage);
    }
}
