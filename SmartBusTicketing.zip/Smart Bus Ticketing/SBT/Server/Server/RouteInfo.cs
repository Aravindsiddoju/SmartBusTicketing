﻿using Server.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace Server
{
    public class RouteInfo
    {
        public Dictionary<int, Destinations> routes;
    }
}
