﻿using MessageTrigger.Interfaces;
using Newtonsoft.Json;
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Text;

namespace MessageTrigger
{
    class MessageSender : IMessageSender
    {
        private ConnectionFactory connectionFactory;
        private IConnection connection;
        private IModel model;
        private string QueueName = "AravindRabbit1";
        string json;

        public void SendMessage()
        {
            CreateQueue();
            
            SendEachMessage();
        }

        private void SendEachMessage()
        {
            IBasicProperties basicProperties = model.CreateBasicProperties();
            Dictionary<string, object> headers = new Dictionary<string, object>();
            while (true)
            {
                Console.WriteLine("enter 0 to send GetBusInfo");
                Console.WriteLine("enter 1 to send BookTicket to server");
                Console.WriteLine("enter 2 to send live location");
                Console.WriteLine("enter 3 to get PassengerInfo");
                Console.WriteLine("enter 4 to EndTrip");
                Console.WriteLine("enter 5 to GetRoute");
                int n = Convert.ToInt32(Console.ReadLine());
                if (n == 0)
                {
                    InputForBus inputForBus = new InputForBus
                    {
                        busId = "987",
                        passengerId = "001"
                    };
                    json = JsonConvert.SerializeObject(inputForBus);
                    //headers.Add("RequestType", "BusInfo");
                    headers["RequestType"] = "BusInfo";
                    byte[] message = System.Text.Encoding.UTF8.GetBytes(json);
                    basicProperties.Headers = headers;
                    model.BasicPublish("", QueueName, basicProperties, message);
                    Console.WriteLine("message has been succesfully sent to queue");
                    Console.WriteLine($"the delivered data of get Businfo is:{json}");
                }
                else if(n==1)
                {
                    DataFromBus dataFromBus = new DataFromBus
                    {
                        bus = new Bus
                        {
                            ServiceNumber = "321",
                            BusId = "987"
                        },
                        passenger = new Passenger
                        {
                            PassengerId = "001",
                            PassengerName = "Sidhu",
                            Amount = 20,
                            NumberOfTickets = 2,
                            DateOfJourney = DateTime.Today,
                            //TimeStampOfJourney = DateTime.Today,
                            FromLocation = "marathalli",
                            ToLocation = "bellandur"

                        }
                    };
                    json = JsonConvert.SerializeObject(dataFromBus);

                    //headers.Add("RequestType", "BookTicket");
                    headers["RequestType"] = "BookTicket";
                    byte[] message = System.Text.Encoding.UTF8.GetBytes(json);
                    basicProperties.Headers = headers;
                    model.BasicPublish("", QueueName, basicProperties, message);
                    Console.WriteLine("message has been succesfully sent to queue");
                    Console.WriteLine($"the delivered data of passenger book ticket is:{json}");
                }
                else if(n==2)
                {
                    LiveLocation liveLocation = new LiveLocation
                    {
                        busId = "987",
                        location = "bellandur"
                    };
                    json = JsonConvert.SerializeObject(liveLocation);
                    headers["RequestType"] = "LiveLocation";
                    byte[] message = System.Text.Encoding.UTF8.GetBytes(json);
                    basicProperties.Headers = headers;
                    model.BasicPublish("", "AravindRabbit2", basicProperties, message);
                    Console.WriteLine("message has been succesfully sent to queue");
                    Console.WriteLine($"the delivered data of Livelocation is:{json}");
                }
                else if(n==3)
                {
                    string passengerId = "001";
                    headers["RequestType"] = "PassengerInfo";
                    byte[] message = System.Text.Encoding.UTF8.GetBytes(passengerId);
                    basicProperties.Headers = headers;
                    model.BasicPublish("", QueueName, basicProperties, message);
                    Console.WriteLine("message has been succesfully sent to queue");
                    Console.WriteLine($"the delivered data of passenger Id is:{json}");

                }
                else if(n==5)
                {
                    string busId = "987";
                    headers["RequestType"] = "GetRoute";
                    byte[] message = System.Text.Encoding.UTF8.GetBytes(json);
                    basicProperties.Headers = headers;
                    model.BasicPublish("", "AravindRabbit2", basicProperties, message);
                    Console.WriteLine("message has been succesfully sent to queue");
                    Console.WriteLine($"the delivered data of GetRoute is:{busId}");
                }

                 

               
                         
            }
        }

        private void CreateQueue()
        {
            connectionFactory = new ConnectionFactory
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "guest"
            };
            connection = connectionFactory.CreateConnection();
            model = connection.CreateModel();
            model.QueueDeclare(QueueName, true, false, false, null);
            model.QueueDeclare("Aravindrabbit2", true, false, false, null);
            model.BasicQos(0, 1, false);
        }
    }
}
