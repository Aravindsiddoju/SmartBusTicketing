﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessageTrigger.Interfaces
{
    public interface IMessageSender
    {
        void SendMessage();
    }
}
