﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessageTrigger
{
    public class Passenger
    {
        private string passengerName;
        private int numberOfTickets;
        private string fromLocation;
        private string toLocation;
        private int amount;
        private DateTime dateOfJourney;

        private string passengerId;

        public string PassengerId
        {
            get { return passengerId; }
            set { passengerId = value; }
        }

        public string PassengerName
        {
            get { return passengerName; }
            set { passengerName = value; }
        }
        public int NumberOfTickets
        {
            get { return numberOfTickets; }
            set { numberOfTickets = value; }
        }
        public string FromLocation
        {
            get { return fromLocation; }
            set { fromLocation = value; }
        }
        public string ToLocation
        {
            get { return toLocation; }
            set { toLocation = value; }
        }
        public int Amount
        {
            get { return amount; }
            set { amount = value; }
        }
        public DateTime DateOfJourney
        {
            get { return dateOfJourney; }
            set { dateOfJourney = value; }
        }
    }
}
