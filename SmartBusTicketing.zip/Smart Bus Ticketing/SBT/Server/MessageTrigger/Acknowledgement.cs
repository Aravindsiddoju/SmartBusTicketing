﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessageTrigger
{
    public class Acknowledgement
    {
        public string PassenerName;
        public string TicketId;
        public DateTime TimeStamp;
    }
}
