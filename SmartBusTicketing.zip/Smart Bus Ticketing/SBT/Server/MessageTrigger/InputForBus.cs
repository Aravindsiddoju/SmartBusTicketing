﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessageTrigger
{
    public class InputForBus
    {
        public string busId;
        public string passengerId;
    }
}
