﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MessageTrigger
{
    class LiveLocation
    {
        public string busId;
        public string location;
    }
}
