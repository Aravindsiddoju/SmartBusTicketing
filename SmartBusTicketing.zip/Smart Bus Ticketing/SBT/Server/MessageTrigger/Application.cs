﻿using MessageTrigger.Interfaces;
using Microsoft.Extensions.Hosting;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MessageTrigger
{
    public class Application : IHostedService
    {
        private ConnectionFactory connectionFactory;
        private IConnection connection;
        private IModel model;
        private string QueueName = "AravindRabbit";
        private IMessageSender messageSender;
        private IMessageListener messageListener;
        public Application(IMessageListener _messageListener, IMessageSender _messageSender)
        {
            messageSender = _messageSender;
            messageListener = _messageListener;
            CreateQueue();
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            var consumer = new EventingBasicConsumer(model);
            Console.WriteLine("application started listening for new messages from server");
            consumer.Received += Consumer_Received;
            model.BasicConsume(QueueName, false, consumer);
            messageSender.SendMessage();

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
        internal void Consumer_Received(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                Console.WriteLine("received a new message from server");
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine("started processing the message");
                //write logic here to acknowledge
                messageListener.ReceivedMessage(messageBody);
                model.BasicAck(e.DeliveryTag, false);

            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }
        //initializes queue;
        private void CreateQueue()
        {
            connectionFactory = new ConnectionFactory
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "guest",
                Port = 5672,
                VirtualHost = "/"
            };
            connection = connectionFactory.CreateConnection();
            model = connection.CreateModel();
            model.QueueDeclare(QueueName, true, false, false, null);
            model.BasicQos(0, 1, false);
        }
    }
}
