﻿using MessageTrigger.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace MessageTrigger
{
    class MessageListener : IMessageListener
    {
        public void ReceivedMessage(string message)
        {
            Acknowledgement acknowledgement = JsonConvert.DeserializeObject<Acknowledgement>(message);
            Console.WriteLine("received acknowledgement by the sever");
            string jsonData = JsonConvert.SerializeObject(acknowledgement);
            Console.WriteLine(jsonData);
        }
    }
}
