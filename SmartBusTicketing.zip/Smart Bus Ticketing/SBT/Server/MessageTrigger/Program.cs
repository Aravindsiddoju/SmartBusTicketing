﻿using MessageTrigger.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using RabbitMQ.Client;
using System;

namespace MessageTrigger
{
    class Program
    {
       
        
        static void Main(string[] args)
        {
            var host = new HostBuilder()
                .ConfigureServices((context, services) =>
                {
                    services.AddSingleton<IHostedService, Application>();
                    services.AddSingleton<IMessageSender, MessageSender>();
                    services.AddSingleton<IMessageListener, MessageListener>();
                });

            host.RunConsoleAsync();                
        }
    }
}
