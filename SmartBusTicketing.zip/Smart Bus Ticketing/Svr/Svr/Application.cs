﻿using Microsoft.Extensions.Hosting;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Svr
{
    class Application : IHostedService
    {
        private ConnectionFactory connectionFactory;
        private IConnection connection;
        private IModel model;
        private string QueueName = "AravindRabbit1";
        public Application()
        {
            connectionFactory = new ConnectionFactory
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "guest",
            };
            connection = connectionFactory.CreateConnection();
            model = connection.CreateModel();
            model.QueueDeclare(QueueName, true, false, false, null);
            model.BasicQos(0, 1, false);
        }
        public Task StartAsync(CancellationToken cancellationToken)
        {
            var consumer = new EventingBasicConsumer(model);
            consumer.Received += Consumer_Received;
            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }

        internal void Consumer_Received(object sender, BasicDeliverEventArgs e)
        {
            try
            {
                var body = e.Body;
                var messageBody = Encoding.UTF8.GetString(body);
                Console.WriteLine($"the received message is : {messageBody}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("error while retrieving the data");
                throw ex;
            }
        }
    }
}
